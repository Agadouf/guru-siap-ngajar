import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaSearch, FaBookOpen, FaVideo, FaHeadphones, FaFileAlt, FaArrowRight } from "react-icons/fa";
import StudentLayout from "../../components/Layout/StudentLayout/StudentLayout";
import { getModules } from "../../services/module.service";
import { getLessons } from "../../services/lesson.service";
import { getExpressions } from "../../services/expression.service";

const icons = ["🌞", "📝", "👥", "⭐", "💬", "👋", "📚", "🎨", "🧩", "💡"];
const colors = ["#d8eeeb", "#f8e3d7", "#dcecf6", "#f9e8bc", "#e4e2fa", "#dcebd8"];

function labelOf(item, fallback) {
  return item?.title || item?.name || fallback;
}

export default function Home() {
  const navigate = useNavigate();
  const [modules, setModules] = useState([]);
  const [lessons, setLessons] = useState([]);
  const [expressions, setExpressions] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    Promise.allSettled([getModules(), getLessons(), getExpressions()]).then((results) => {
      if (!active) return;
      if (results[0].status === "fulfilled") setModules(Array.isArray(results[0].value) ? results[0].value : []);
      if (results[1].status === "fulfilled") setLessons(Array.isArray(results[1].value) ? results[1].value : []);
      if (results[2].status === "fulfilled") setExpressions(Array.isArray(results[2].value) ? results[2].value : []);
      setLoading(false);
    });
    return () => { active = false; };
  }, []);

  const videoCount = expressions.filter((item) => item.videoUrl || item.video_url).length;
  const featured = useMemo(() => lessons.slice(0, 3), [lessons]);
  const searchMaterials = () => navigate(`/modules${search.trim() ? `?q=${encodeURIComponent(search.trim())}` : ""}`);

  return (
    <StudentLayout>
      <section className="siap-hero">
        <div className="siap-hero-copy">
          <span className="siap-eyebrow">✦ RUANG BELAJAR MANDIRI GURU SD</span>
          <h1>SIAP English<span>Siap mengajar Bahasa Inggris <mark className="siap-highlight">untuk Guru SD</mark></span></h1>
          <p>Temukan ungkapan bahasa Inggris, contoh penggunaan, dan materi praktis untuk membantu guru mengajar dengan lebih percaya diri.</p>
          <form className="siap-search" onSubmit={(event) => { event.preventDefault(); searchMaterials(); }}>
            <FaSearch aria-hidden="true" />
            <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Cari ungkapan, misalnya: memberi instruksi…" aria-label="Cari materi" />
            <button type="submit">Cari materi</button>
          </form>
          <div className="siap-search-hints"><span>Contoh pencarian:</span>{["membuka pelajaran", "instruksi", "pujian", "kerja kelompok"].map((item) => <button type="button" key={item} onClick={() => { setSearch(item); navigate(`/modules?q=${encodeURIComponent(item)}`); }}>{item}</button>)}</div>
        </div>
        <div className="siap-hero-art" aria-label="Ilustrasi suasana kelas">
          <div className="siap-classroom"><div className="siap-board">Let’s get started!<small>Small steps, brighter classrooms</small></div><div className="siap-people"><div className="siap-person">🧑🏽‍🏫</div><div className="siap-person">🧒🏻</div><div className="siap-person">👧🏽</div><div className="siap-person">🧒🏿</div></div></div>
          <div className="siap-floating-note">Belajar sesuai kebutuhan ✨</div>
        </div>
      </section>

      <section className="siap-features" aria-label="Fitur platform">
        {[
          { icon: <FaBookOpen />, title: "Materi berbasis situasi", desc: "Ungkapan untuk kegiatan mengajar.", color: "#dcebd8" },
          { icon: <FaVideo />, title: "Video pembelajaran", desc: "Tonton video yang tersedia.", color: "#f8e3d7" },
          { icon: <FaHeadphones />, title: "Latihan pelafalan", desc: "Dengarkan ungkapan bahasa Inggris.", color: "#dcecf6" },
          { icon: <FaFileAlt />, title: "Materi praktis", desc: "Jelajahi materi dengan mudah.", color: "#e5e1fa" },
        ].map((item) => <div className="siap-feature" key={item.title}><span className="siap-feature-icon" style={{ background: item.color }}>{item.icon}</span><div><h3>{item.title}</h3><p>{item.desc}</p></div></div>)}
      </section>

      <div className="siap-section-head"><div><h2>Pilih materi sesuai kebutuhan Anda</h2><p>Pilih topik untuk mulai menjelajahi materi.</p></div><Link className="siap-text-link" to="/modules">Lihat semua <FaArrowRight style={{ display: "inline" }} /></Link></div>
      {loading ? <div className="siap-empty">Memuat materi…</div> : modules.length ? (
        <div className="siap-categories">
          {modules.slice(0, 6).map((module, index) => <Link to={`/modules/${module.id}/lessons`} className="siap-category" key={module.id}>
            <div className="siap-category-art" style={{ background: colors[index % colors.length] }}>{icons[index % icons.length]}</div>
            <div className="siap-category-body"><strong>{labelOf(module, "Materi")} <span style={{ float: "right" }}>›</span></strong><small>{lessons.filter((lesson) => String(lesson.moduleId ?? lesson.module_id ?? lesson.module?.id) === String(module.id)).length} topik</small></div>
          </Link>)}
        </div>
      ) : <div className="siap-empty">Materi akan muncul di sini setelah tersedia.</div>}

      <div className="siap-section-head"><div><h2>Materi pilihan</h2><p>Mulai dari salah satu pelajaran yang tersedia.</p></div><Link className="siap-text-link" to="/modules">Semua materi <FaArrowRight style={{ display: "inline" }} /></Link></div>
      {featured.length ? <div className="siap-cards">{featured.map((lesson, index) => {
        const moduleId = lesson.moduleId ?? lesson.module_id ?? lesson.module?.id;
        return <article className="siap-card" key={lesson.id}><div className="siap-card-art" style={{ background: `linear-gradient(135deg,${colors[index % colors.length]},#fff8e8)` }}>{icons[(index + 1) % icons.length]}</div><div className="siap-card-body"><span className="siap-tag">{lesson.module?.title || modules.find((m) => String(m.id) === String(moduleId))?.title || "Materi kelas"}</span><h3>{lesson.title}</h3><p>{lesson.description || "Jelajahi ungkapan bahasa Inggris untuk pelajaran ini."}</p><div className="siap-card-meta"><span>📚 Materi pembelajaran</span><span>🎧 Ungkapan</span></div><Link className="siap-open-btn" to={`/lessons/${lesson.id}/expressions`}>Buka materi →</Link></div></article>;
      })}</div> : <div className="siap-empty">Belum ada pelajaran untuk ditampilkan.</div>}

      <div className="siap-section-head"><div><h2>Belajar dengan lebih praktis</h2><p>Semua materi utama tersedia melalui menu di atas.</p></div></div>
      <div className="siap-features">
        <div className="siap-feature"><span className="siap-feature-icon" style={{background:"#f9e8bc"}}>🎯</span><div><h3>{modules.length} kategori materi</h3><p>Materi yang dikelola melalui platform.</p></div></div>
        <div className="siap-feature"><span className="siap-feature-icon" style={{background:"#dcecf6"}}>📖</span><div><h3>{lessons.length} pelajaran</h3><p>Pelajaran yang dapat dijelajahi.</p></div></div>
        <div className="siap-feature"><span className="siap-feature-icon" style={{background:"#e5e1fa"}}>💬</span><div><h3>{expressions.length} ungkapan</h3><p>Ungkapan dan terjemahan.</p></div></div>
        <div className="siap-feature"><span className="siap-feature-icon" style={{background:"#dcebd8"}}>▶</span><div><h3>{videoCount} video</h3><p>Video yang tersedia pada materi.</p></div></div>
      </div>
    </StudentLayout>
  );
}
