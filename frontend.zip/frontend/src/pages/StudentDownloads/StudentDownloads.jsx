import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FaDownload, FaFileAlt } from "react-icons/fa";
import StudentLayout from "../../components/Layout/StudentLayout/StudentLayout";
import { getLessons } from "../../services/lesson.service";
import { getExpressions } from "../../services/expression.service";

function saveSummary(lesson, expressions) {
  const text = `SIAP ENGLISH — RINGKASAN MATERI\n\nPelajaran: ${lesson.title}\n${lesson.description || ""}\n\n${expressions.map((item, i) => `${i + 1}. ${item.english || ""}\nTerjemahan: ${item.indonesian || "—"}\nPenjelasan: ${item.explanation || "—"}`).join("\n\n")}`;
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = `SIAP-English-${lesson.title.replace(/[^a-z0-9]+/gi, "-")}.txt`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function StudentDownloads() {
  const [lessons, setLessons] = useState([]);
  const [expressions, setExpressions] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let active = true;
    Promise.all([getLessons(), getExpressions()]).then(([lessonData, expressionData]) => {
      if (!active) return;
      setLessons(Array.isArray(lessonData) ? lessonData : []);
      setExpressions(Array.isArray(expressionData) ? expressionData : []);
    }).catch(console.error).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);
  return <StudentLayout>
    <div className="siap-page-heading"><span className="siap-eyebrow">SUMBER PRAKTIS</span><h1>Unduh materi</h1><p>Unduh ringkasan teks berisi ungkapan, terjemahan, dan penjelasan untuk membantu persiapan mengajar.</p></div>
    {loading ? <div className="siap-empty">Memuat materi…</div> : lessons.length ? <div className="siap-cards">{lessons.map((lesson) => {
      const related = expressions.filter((item) => String(item.lessonId ?? item.lesson_id ?? item.lesson?.id) === String(lesson.id));
      return <article className="siap-card" key={lesson.id}><div className="siap-card-art" style={{background:"#dcecf6"}}><FaFileAlt /></div><div className="siap-card-body"><span className="siap-tag">RINGKASAN MATERI</span><h3>{lesson.title}</h3><p>{lesson.description || "Ringkasan ungkapan dan terjemahan untuk pelajaran ini."}</p><div className="siap-card-meta"><span>💬 {related.length} ungkapan</span><span>.TXT</span></div><button className="siap-open-btn" onClick={() => saveSummary(lesson, related)}><FaDownload style={{display:"inline",marginRight:7}}/> Unduh ringkasan</button><Link className="siap-open-btn" to={`/lessons/${lesson.id}/expressions`}>Lihat materi →</Link></div></article>;
    })}</div> : <div className="siap-empty">Belum ada materi untuk diunduh.</div>}
  </StudentLayout>;
}
