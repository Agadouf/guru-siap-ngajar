import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import StudentLayout from "../../components/Layout/StudentLayout/StudentLayout";
import { getExpressions } from "../../services/expression.service";
import { getLessons } from "../../services/lesson.service";

export default function StudentVideos() {
  const [items, setItems] = useState([]);
  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [video, setVideo] = useState(null);
  useEffect(() => {
    let active = true;
    Promise.all([getExpressions(), getLessons()]).then(([expressions, lessonData]) => {
      if (!active) return;
      setLessons(Array.isArray(lessonData) ? lessonData : []);
      setItems((Array.isArray(expressions) ? expressions : []).filter((item) => item.videoUrl || item.video_url));
    }).catch(console.error).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);
  return <StudentLayout>
    <div className="siap-page-heading"><span className="siap-eyebrow">LIHAT & TIRUKAN</span><h1>Video pembelajaran</h1><p>Tonton video yang ditambahkan ke materi untuk melihat contoh penggunaan ungkapan.</p></div>
    {loading ? <div className="siap-empty">Memuat video…</div> : items.length ? <div className="siap-cards">{items.map((item, index) => {
      const lessonId = item.lessonId ?? item.lesson_id ?? item.lesson?.id;
      const lesson = lessons.find((entry) => String(entry.id) === String(lessonId));
      return <article className="siap-card" key={item.id}><div className="siap-card-art" style={{background:["#dcecf6","#f8e3d7","#f9e8bc"][index%3]}}>▶️</div><div className="siap-card-body"><span className="siap-tag">{lesson?.title || item.lesson?.title || "Materi pembelajaran"}</span><h3>{item.english || "Video ungkapan"}</h3><p>{item.indonesian || item.explanation || "Video untuk membantu memahami penggunaan ungkapan."}</p><button className="siap-open-btn" onClick={() => setVideo(item.videoUrl || item.video_url)}>▶ Tonton video</button>{lessonId && <Link className="siap-open-btn" to={`/lessons/${lessonId}/expressions`}>Buka pelajaran →</Link>}</div></article>;
    })}</div> : <div className="siap-empty"><div style={{fontSize:38}}>🎬</div><strong>Belum ada video</strong><p>Video akan muncul di sini setelah admin menambahkannya ke ungkapan.</p><Link className="siap-open-btn" to="/modules">Jelajahi materi</Link></div>}
    {video && <div role="dialog" aria-modal="true" className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4" onClick={() => setVideo(null)}><div className="w-full max-w-4xl rounded-2xl bg-white p-4" onClick={(e) => e.stopPropagation()}><video src={video} controls autoPlay className="siap-video-real"/><button className="siap-open-btn" onClick={() => setVideo(null)}>Tutup video</button></div></div>}
  </StudentLayout>;
}
