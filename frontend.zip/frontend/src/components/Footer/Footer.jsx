import { Link } from "react-router-dom";
import { FaSun, FaBookOpen, FaVideo, FaDownload } from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="siap-footer">
      <div className="siap-footer-inner">
        <div className="siap-footer-brand"><span className="siap-logo"><FaSun /></span><div><strong>SIAP English</strong><p>Belajar dengan langkah kecil, mengajar dengan lebih percaya diri.</p></div></div>
        <div className="siap-footer-links"><Link to="/modules"><FaBookOpen /> Materi</Link><Link to="/videos"><FaVideo /> Video</Link><Link to="/downloads"><FaDownload /> Unduhan</Link><Link to="/about">Tentang</Link></div>
        <p className="siap-copyright">© {new Date().getFullYear()} SIAP English · Guru Siap Ngajar</p>
      </div>
    </footer>
  );
}
