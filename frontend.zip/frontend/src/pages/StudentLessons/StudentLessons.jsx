import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import StudentLayout from "../../components/Layout/StudentLayout/StudentLayout";
import { getLessons } from "../../services/lesson.service";
import { getModules } from "../../services/module.service";

const icons = ["📖", "🗣️", "✏️", "🎯", "💬", "⭐"];

export default function StudentLessons() {
  const { moduleId } = useParams();
  const [lessons, setLessons] = useState([]);
  const [module, setModule] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    setLoading(true);
    Promise.all([getLessons(moduleId), getModules()])
      .then(([lessonData, moduleData]) => {
        if (!active) return;
        setLessons(Array.isArray(lessonData) ? lessonData : []);
        setModule((Array.isArray(moduleData) ? moduleData : []).find((item) => String(item.id) === String(moduleId)) || null);
      })
      .catch((err) => { console.error(err); if (active) setError("Pelajaran belum dapat dimuat. Silakan coba lagi."); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [moduleId]);

  return <StudentLayout>
    <p className="siap-crumb"><Link to="/">Beranda</Link>　›　<Link to="/modules">Materi</Link>　›　{module?.title || "Pelajaran"}</p>
    <div className="siap-page-heading"><span className="siap-eyebrow">MATERI PEMBELAJARAN</span><h1>{module?.title || "Daftar pelajaran"}</h1><p>{module?.description || "Pilih pelajaran untuk melihat ungkapan, terjemahan, dan video yang tersedia."}</p></div>
    {loading ? <div className="siap-empty">Memuat pelajaran…</div> : error ? <div className="siap-empty">{error}<button className="siap-open-btn" onClick={() => window.location.reload()}>Coba lagi</button></div> : lessons.length ? <div className="siap-cards">{lessons.map((lesson, index) => <article className="siap-card" key={lesson.id}><div className="siap-card-art" style={{background:["#dcecf6","#f8e3d7","#f9e8bc","#e4e2fa"][index%4]}}>{icons[index%icons.length]}</div><div className="siap-card-body"><span className="siap-tag">PELAJARAN {String(index+1).padStart(2,"0")}</span><h3>{lesson.title}</h3><p>{lesson.description || "Pelajari ungkapan yang dapat digunakan dalam situasi ini."}</p><div className="siap-card-meta"><span>💬 Ungkapan bahasa Inggris</span><span>↗ Materi</span></div><Link className="siap-open-btn" to={`/lessons/${lesson.id}/expressions`}>Buka pelajaran →</Link></div></article>)}</div> : <div className="siap-empty"><div style={{fontSize:34}}>📚</div><strong>Belum ada pelajaran</strong><p>Pelajaran untuk materi ini akan tampil di sini setelah ditambahkan oleh admin.</p><Link className="siap-open-btn" to="/modules">Kembali ke materi</Link></div>}
  </StudentLayout>;
}
