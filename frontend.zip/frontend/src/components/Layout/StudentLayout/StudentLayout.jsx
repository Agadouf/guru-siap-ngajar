import Navbar from "../../Navbar/Navbar";
import Footer from "../../Footer/Footer";
import "../../student-theme.css";

export default function StudentLayout({ children }) {
  return (
    <div className="siap-app">
      <Navbar />
      <main className="siap-main">{children}</main>
      <Footer />
    </div>
  );
}
