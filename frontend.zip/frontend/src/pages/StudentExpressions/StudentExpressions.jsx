import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { FaVolumeUp, FaPlay, FaDownload, FaHeart } from "react-icons/fa";
import StudentLayout from "../../components/Layout/StudentLayout/StudentLayout";
import { getExpressions } from "../../services/expression.service";
import { getLessons } from "../../services/lesson.service";

function speak(text) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-US";
  utterance.rate = 0.82;
  window.speechSynthesis.speak(utterance);
}
function downloadText(lesson, expressions) {
  const text = `${lesson?.title || "SIAP English"}\n\n${expressions.map((item, index) => `${index + 1}. ${item.english || ""}\nTerjemahan: ${item.indonesian || "—"}\nPenjelasan: ${item.explanation || "—"}`).join("\n\n")}`;
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `SIAP-English-${(lesson?.title || "materi").replace(/[^a-z0-9]+/gi, "-")}.txt`;
  anchor.click();
  URL.revokeObjectURL(url);
}

export default function StudentExpressions() {
  const { lessonId } = useParams();
  const [expressions, setExpressions] = useState([]);
  const [lesson, setLesson] = useState(null);
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);
  const [activeTab, setActiveTab] = useState("expressions");

  useEffect(() => {
    let active = true;
    Promise.all([getExpressions(), getLessons()])
      .then(([expressionData, lessonData]) => {
        if (!active) return;
        setExpressions((Array.isArray(expressionData) ? expressionData : []).filter((item) => String(item.lessonId ?? item.lesson_id ?? item.lesson?.id) === String(lessonId)));
        setLesson((Array.isArray(lessonData) ? lessonData : []).find((item) => String(item.id) === String(lessonId)) || null);
      })
      .catch((err) => { console.error(err); if (active) setError("Ungkapan belum dapat dimuat. Silakan coba lagi."); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [lessonId]);

  const videos = useMemo(() => expressions.filter((item) => item.videoUrl || item.video_url), [expressions]);

  return <StudentLayout>
    <p className="siap-crumb"><Link to="/">Beranda</Link>　›　<Link to="/modules">Materi</Link>　›　{lesson?.title || "Detail pelajaran"}</p>
    <div className="siap-lesson-title"><div><span className="siap-tag">UNGKAPAN BAHASA INGGRIS</span><h1>{lesson?.title || "Ungkapan pelajaran"}</h1><p>{lesson?.description || "Ungkapan praktis beserta terjemahan dan contoh penggunaannya."}</p></div><button className="siap-icon-link" style={{width:44,height:44}} aria-label="Simpan materi" onClick={() => setSaved(!saved)}><FaHeart style={{color:saved ? "#e4546d" : "#66758a"}} /></button></div>
    {videos.length > 0 ? <div className="siap-video-box" style={{marginBottom:18}}><strong>Video pembelajaran</strong><p>Pilih video yang ingin ditonton.</p><div style={{display:"flex",gap:10,flexWrap:"wrap",justifyContent:"center"}}>{videos.map((item) => <button className="siap-open-btn" style={{width:"auto",padding:"10px 16px"}} key={item.id} onClick={() => setSelectedVideo(item.videoUrl || item.video_url)}><FaPlay style={{display:"inline",marginRight:7}} />{item.english || "Putar video"}</button>)}</div></div> : <div className="siap-video-box" style={{marginBottom:18}}><div style={{fontSize:42}}>🧑🏽‍🏫</div><strong>Belajar melalui ungkapan</strong><p>Video belum tersedia untuk pelajaran ini. Anda tetap dapat membaca dan mendengarkan ungkapan.</p></div>}
    <div className="siap-tabs">{[{id:"expressions",label:"Ungkapan"},{id:"explanation",label:"Penjelasan"},{id:"videos",label:"Video"},{id:"download",label:"Unduh materi"}].map((tab) => <button key={tab.id} className={`siap-tab ${activeTab===tab.id?"active":""}`} onClick={() => setActiveTab(tab.id)}>{tab.label}</button>)}</div>
    {loading ? <div className="siap-empty">Memuat ungkapan…</div> : error ? <div className="siap-empty">{error}<button className="siap-open-btn" onClick={() => window.location.reload()}>Coba lagi</button></div> : activeTab === "expressions" ? expressions.length ? expressions.map((expression) => <article className="siap-expression" key={expression.id}><button className="siap-sound" onClick={() => speak(expression.english || "")} aria-label={`Dengarkan ${expression.english}`}><FaVolumeUp /></button><div style={{flex:1}}><h3>{expression.english}</h3><p>{expression.indonesian || "Terjemahan belum tersedia."}</p>{expression.explanation && <p style={{marginTop:8}}>{expression.explanation}</p>}</div>{(expression.videoUrl || expression.video_url) && <button className="siap-icon-link" onClick={() => setSelectedVideo(expression.videoUrl || expression.video_url)} aria-label="Putar video"><FaPlay /></button>}</article>) : <div className="siap-empty">Belum ada ungkapan untuk pelajaran ini.</div> : activeTab === "explanation" ? expressions.length ? expressions.map((item) => <div className="siap-info" key={item.id}><strong>{item.english}</strong><p>{item.explanation || "Belum ada penjelasan tambahan."}</p></div>) : <div className="siap-empty">Belum ada penjelasan.</div> : activeTab === "videos" ? videos.length ? videos.map((item) => <div className="siap-phrase-row" key={item.id}><span>{item.english || "Video pembelajaran"}</span><button onClick={() => setSelectedVideo(item.videoUrl || item.video_url)}><FaPlay style={{display:"inline",marginRight:6}}/> Putar video</button></div>) : <div className="siap-empty">Video belum tersedia untuk pelajaran ini.</div> : <div className="siap-info"><h3 style={{fontWeight:850,color:"var(--siap-navy)"}}>Unduh ringkasan pelajaran</h3><p>Unduh ungkapan, terjemahan, dan penjelasan sebagai file teks.</p><button className="siap-open-btn" onClick={() => downloadText(lesson, expressions)}><FaDownload style={{display:"inline",marginRight:8}}/> Unduh ringkasan (.txt)</button></div>}
    {selectedVideo && <div role="dialog" aria-modal="true" className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4" onClick={() => setSelectedVideo(null)}><div className="w-full max-w-4xl rounded-2xl bg-white p-4" onClick={(event) => event.stopPropagation()}><video src={selectedVideo} controls autoPlay className="siap-video-real"/><div style={{display:"flex",justifyContent:"flex-end",marginTop:12}}><button className="siap-open-btn" style={{width:"auto",padding:"10px 20px"}} onClick={() => setSelectedVideo(null)}>Tutup video</button></div></div></div>}
  </StudentLayout>;
}
