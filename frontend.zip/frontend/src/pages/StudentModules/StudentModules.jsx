import { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { FaSearch, FaBookOpen } from "react-icons/fa";
import StudentLayout from "../../components/Layout/StudentLayout/StudentLayout";
import { getModules } from "../../services/module.service";
import { getLessons } from "../../services/lesson.service";

const icons = ["🌞", "📝", "👥", "⭐", "💬", "👋", "📚", "🎨"];
const colors = ["#d8eeeb", "#f8e3d7", "#dcecf6", "#f9e8bc", "#e4e2fa", "#dcebd8"];

export default function StudentModules() {
  const [searchParams] = useSearchParams();
  const [modules, setModules] = useState([]);
  const [lessons, setLessons] = useState([]);
  const [search, setSearch] = useState(searchParams.get("q") || "");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    Promise.all([getModules(), getLessons()])
      .then(([moduleData, lessonData]) => {
        if (!active) return;
        setModules(Array.isArray(moduleData) ? moduleData : []);
        setLessons(Array.isArray(lessonData) ? lessonData : []);
      })
      .catch((err) => {
        console.error("Failed to load learning materials:", err);
        if (active) setError("Materi belum dapat dimuat. Silakan coba lagi.");
      })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  useEffect(() => { setSearch(searchParams.get("q") || ""); }, [searchParams]);

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return modules;
    return modules.filter((module) => {
      const moduleLessons = lessons.filter((lesson) => String(lesson.moduleId ?? lesson.module_id ?? lesson.module?.id) === String(module.id));
      return [module.title, module.description, ...moduleLessons.flatMap((lesson) => [lesson.title, lesson.description])].filter(Boolean).join(" ").toLowerCase().includes(query);
    });
  }, [modules, lessons, search]);

  return <StudentLayout>
    <div className="siap-page-heading"><span className="siap-eyebrow">PERPUSTAKAAN BELAJAR</span><h1>Jelajahi materi</h1><p>Pilih topik atau cari materi yang sesuai dengan kebutuhan mengajar Anda.</p></div>
    <form className="siap-search siap-search-page" onSubmit={(e) => e.preventDefault()}><FaSearch /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari ungkapan, pelajaran, atau situasi kelas…" aria-label="Cari materi" /><button type="button" onClick={() => setSearch("")}>Reset</button></form>
    <div className="siap-content-grid">
      <aside className="siap-sidebar"><h3>Kategori materi</h3><button className={`siap-side-link ${!search ? "active" : ""}`} onClick={() => setSearch("")}><span>▦</span> Semua materi</button>{modules.map((module, index) => <button key={module.id} className="siap-side-link" onClick={() => setSearch(module.title || "")}><span>{icons[index % icons.length]}</span>{module.title}</button>)}</aside>
      <div>
        {loading ? <div className="siap-empty">Memuat materi…</div> : error ? <div className="siap-empty">{error}<br/><button className="siap-open-btn" onClick={() => window.location.reload()}>Coba lagi</button></div> : filtered.length ? <div className="siap-cards">{filtered.map((module, index) => {
          const count = lessons.filter((lesson) => String(lesson.moduleId ?? lesson.module_id ?? lesson.module?.id) === String(module.id)).length;
          return <article className="siap-card" key={module.id}><div className="siap-card-art" style={{background:`linear-gradient(135deg,${colors[index % colors.length]},#fff8e8)`}}>{icons[index % icons.length]}</div><div className="siap-card-body"><span className="siap-tag">MATERI PEMBELAJARAN</span><h3>{module.title}</h3><p>{module.description || "Jelajahi pelajaran dan ungkapan yang tersedia dalam materi ini."}</p><div className="siap-card-meta"><span>📚 {count} pelajaran</span><span>↗ Belajar</span></div><Link className="siap-open-btn" to={`/modules/${module.id}/lessons`}>Lihat pelajaran →</Link></div></article>;
        })}</div> : <div className="siap-empty"><FaBookOpen style={{fontSize:32,margin:"0 auto 12px"}}/><strong>Tidak ada materi ditemukan</strong><p>Coba kata kunci lain.</p></div>}
      </div>
    </div>
  </StudentLayout>;
}
