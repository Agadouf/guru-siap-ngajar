import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { FaSun, FaBars, FaTimes, FaSearch, FaHeart } from "react-icons/fa";

const links = [
  { to: "/", label: "Beranda" },
  { to: "/modules", label: "Materi" },
  { to: "/videos", label: "Video" },
  { to: "/downloads", label: "Unduhan" },
  { to: "/about", label: "Tentang" },
];

export default function Navbar() {
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const active = (to) => to === "/" ? location.pathname === "/" : location.pathname === to || location.pathname.startsWith(to + "/");

  return (
    <header className="siap-header">
      <div className="siap-nav">
        <Link to="/" className="siap-brand" onClick={() => setOpen(false)}>
          <span className="siap-logo"><FaSun /></span>
          <span><strong>SIAP English</strong><small>Siap Mengajar dengan Bahasa Inggris</small></span>
        </Link>
        <nav className={`siap-links ${open ? "is-open" : ""}`} aria-label="Navigasi utama">
          {links.map((link) => <Link key={link.to} to={link.to} onClick={() => setOpen(false)} className={active(link.to) ? "active" : ""}>{link.label}</Link>)}
        </nav>
        <div className="siap-nav-actions">
          <Link to="/modules" className="siap-icon-link" aria-label="Cari materi"><FaSearch /></Link>
          <Link to="/modules" className="siap-favorites"><FaHeart /> Materi <span>♥</span></Link>
          <button className="siap-menu-toggle" onClick={() => setOpen(!open)} aria-label={open ? "Tutup menu" : "Buka menu"}>{open ? <FaTimes /> : <FaBars />}</button>
        </div>
      </div>
    </header>
  );
}
