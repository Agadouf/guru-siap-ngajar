import { Link } from "react-router-dom";
import { FaBookOpen, FaVideo, FaHeadphones, FaFileAlt } from "react-icons/fa";
import StudentLayout from "../../components/Layout/StudentLayout/StudentLayout";

export default function About() {
  const items = [
    { icon: <FaBookOpen />, title: "Materi berbasis situasi", text: "Jelajahi pelajaran yang dikelompokkan untuk membantu kebutuhan belajar." , color:"#dcebd8"},
    { icon: <FaVideo />, title: "Video pembelajaran", text: "Tonton video yang tersedia bersama materi dan ungkapan." , color:"#f8e3d7"},
    { icon: <FaHeadphones />, title: "Latihan pelafalan", text: "Dengarkan contoh pengucapan ungkapan bahasa Inggris melalui browser." , color:"#dcecf6"},
    { icon: <FaFileAlt />, title: "Ringkasan praktis", text: "Unduh ringkasan teks untuk membantu persiapan mengajar." , color:"#e5e1fa"},
  ];
  return <StudentLayout>
    <div className="siap-page-heading"><span className="siap-eyebrow">TENTANG SIAP ENGLISH</span><h1>Belajar dengan langkah kecil</h1><p>SIAP English membantu guru menjelajahi ungkapan bahasa Inggris dan materi praktis untuk kegiatan pembelajaran.</p></div>
    <section className="siap-hero-art" style={{minHeight:210,marginBottom:24}}><div className="siap-classroom"><div className="siap-board">Small Steps, Brighter Classrooms<small>Materi praktis untuk kegiatan belajar sehari-hari</small></div><div className="siap-people"><div className="siap-person">🧑🏽‍🏫</div><div className="siap-person">🧒🏻</div><div className="siap-person">👧🏽</div></div></div></section>
    <div className="siap-section-head"><div><h2>Yang tersedia di platform</h2><p>Jelajahi materi sesuai kebutuhan Anda.</p></div></div>
    <div className="siap-cards">{items.map((item) => <article className="siap-card" key={item.title}><div className="siap-card-art" style={{background:item.color,color:"var(--siap-navy)"}}>{item.icon}</div><div className="siap-card-body"><h3>{item.title}</h3><p>{item.text}</p></div></article>)}</div>
    <div className="siap-info" style={{marginTop:24}}><h2 style={{fontWeight:850,color:"var(--siap-navy)",fontSize:20}}>Mulai menjelajahi materi</h2><p>Materi, ungkapan, terjemahan, dan video ditampilkan berdasarkan konten yang tersedia di platform.</p><Link className="siap-open-btn" to="/modules">Lihat semua materi →</Link></div>
  </StudentLayout>;
}
